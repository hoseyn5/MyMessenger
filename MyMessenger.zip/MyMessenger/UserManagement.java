package MyMessenger;



import java.util.HashMap;

public class UserManagement {

    public static UserManagement userManagement;
    private final HashMap<Integer, User> userMap = new HashMap<>();

    public static UserManagement getInstance(){
        if(userManagement == null){
            userManagement = new UserManagement();
        }
        return userManagement;
    }

    public void acceptFriendshipRequest(FrienshipRequest fr){
        User user1 = fr.getFromUser();
        User user2 = fr.getToUser();
        user1.addContact(user2);
        user2.addContact(user1);
    }

    public void rejectFriendshipRequest(FrienshipRequest fr){
        User user1 = fr.getFromUser();
        User user2 = fr.getToUser();
        user2.rejectContact(user1);
    }

    public void addUser(User user){
        userMap.put(user.getId(), user);
    }

    public void removeUser(User user){
        userMap.remove(user.getId());
    }

    public void login(User user){
        user.setStatus("ACTIVE");
    }

    public void logOut(User user){
        user.setStatus("PASSIVE");
    }

    public HashMap<Integer, User> getAllUserList() {
        return userMap;
    }
}
