package MyMessenger;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MessageSystem {

    public static void main(String[] args) {

        User user1 = new User("sara", "Soheili","sara@gmail.com");
        User user2 = new User("salar",  "Saraiee","salar@gmail.com");
        User user3 = new User("soheil","Salari","soheil@gmail.com");

        UserManagement userManager = UserManagement.getInstance();

        userManager.addUser(user1);
        userManager.addUser(user2);
        userManager.addUser(user3);

        // Get all user list
        HashMap<Integer, User> userAllMap = userManager.getAllUserList();

        System.out.println("All user list");

        for(Map.Entry<Integer, User> userEntry : userAllMap.entrySet()){
            System.out.println("User :" + userEntry.getValue().getName());
        }

        FrienshipRequest frienshipRequest = new FrienshipRequest(user1, user2);
        userManager.acceptFriendshipRequest(frienshipRequest);

        FrienshipRequest friendshipRequest1 = new FrienshipRequest(user2, user3);
        userManager.acceptFriendshipRequest(friendshipRequest1);

        // Get users friends list
        for(Map.Entry<Integer, User> userEntry : userAllMap.entrySet()){
            User user = userEntry.getValue();
            System.out.println("Friends of :" + user.getName());

            HashMap<Integer, User> friendsMap = user.getFriendsList();
            for(Map.Entry<Integer, User> friendsMapEntry : friendsMap.entrySet()) {
                System.out.println(friendsMapEntry.getValue().getName());
            }
        }
        user1.sendMessageToPrivateConversation(user2,"Hi,whats up?");
        user2.sendMessageToPrivateConversation(user1,"Fine, You ?");

        Conversation conversation = user1.getPrivateConversations(user2);

        List<Message> messageList = conversation.getConversation();

        for(Message message : messageList){
            System.out.println("Message : " + message.getContent() + " / Date :" + message.getDate());
        }
    }
}