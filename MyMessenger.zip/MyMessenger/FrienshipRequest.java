package MyMessenger;

public class FrienshipRequest {

    private final User toUser;
    private final User fromUser;

    public FrienshipRequest(User toUser, User fromUser){
        this.toUser = toUser;
        this.fromUser = fromUser;
    }

    public User getToUser() {
        return toUser;
    }

    public User getFromUser() {
        return fromUser;
    }

}
