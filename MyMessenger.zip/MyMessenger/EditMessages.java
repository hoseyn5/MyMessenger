package MyMessenger;

public class EditMessages {

    private  String content;
    private  Date date;

    public Message(String content,Date date){
        this.content = Editedcontent;
        this.date = date;
    }

    public String getEditedContent() {
        return Editdcontent;
    }

    public Date getDate() {
        return date;
    }

}

}
