package MyMessenger;

public class GroupConversation extends Conversation {

    public GroupConversation() {
        super();
    }


    protected void addParticipant(User user) {
        super.addParticipant(user);
    }


    public void addMessage(Message message) { }

}
