package MyMessenger;

import java.util.ArrayList;
import java.util.List;

public class Conversation {

    protected int conversationId;
    protected List<Message> conversation = new ArrayList<>();
    protected List<User> participants = new ArrayList<>();

    protected void addParticipant(User user){
        participants.add(user);
    }

    protected void addMessage(Message message){ conversation.add(message); }

    public int getConversationId() {
        return conversationId;
    }

    public List<Message> getConversation() {
        return conversation;
    }

    public List<User> getParticipants() {
        return participants;
    }

}
