package MyMessenger;

import java.util.Date;
import java.util.HashMap;

public class User {

    private int id;
    private String name;
    private String surname;
    private String email;
    private String status;

    private HashMap<Integer, User> waitingRequests = new HashMap<>();
    private HashMap<Integer, User> friendList = new HashMap<>();
    private HashMap<Integer, PrivateConversation> privateConversation = new HashMap<>();
    private HashMap<Integer, GroupConversation> groupConversations = new HashMap<>();

    public User(String name,String surname,String email){
        this.id = name.hashCode();
        this.name = name;
        this.surname = surname;
        this.email = email;
    }

    public void sendMessageToPrivateConversation(User toUser,String content){
        Message message = new Message(content,new Date());
        PrivateConversation conversation = privateConversation.get(toUser.getId());
        if(conversation == null){
            conversation = new PrivateConversation(this, toUser);
        }
        conversation.addMessage(message);
        privateConversation.put(toUser.getId(),conversation);
        toUser.privateConversation.put(this.getId(),conversation);
    }

    public void sendMessageToGroupConversation(GroupConversation conversation,String content){
        Message message = new Message(content,new Date());
        GroupConversation groupConversation = groupConversations.get(conversation);
        if(conversation == null) {
            conversation = new GroupConversation();
        }conversation.addMessage(message);

        groupConversations.put(conversation.getConversationId(),conversation);
    }

    public void addContact(User user) {
        waitingRequests.remove(user.getId());
        friendList.put(user.getId(), user);
    }

    public void rejectContact(User user) {
        waitingRequests.remove(user.getId());
    }

    public void sendFriendshipRequest(User toUser){
        FrienshipRequest fr = new FrienshipRequest(this, toUser);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getEmail() {
        return email;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public HashMap<Integer, User> getFriendsList() {
        return friendList;
    }

    public HashMap<Integer, User> getWaitingRequests() {
        return waitingRequests;
    }

    public HashMap<Integer, User> getFriendList() {
        return friendList;
    }

    public PrivateConversation getPrivateConversations(User user) {
        return privateConversation.get(user.getId());
    }

    public HashMap<Integer, GroupConversation> getGroupConversations() {
        return groupConversations;
    }
}
