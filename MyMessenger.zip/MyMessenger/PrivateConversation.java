package MyMessenger;

public class PrivateConversation extends Conversation {

    public PrivateConversation(User user1, User user2) {
        participants.add(user1);
        participants.add(user2);
    }

    public User getOtherParticipant(User user){

        if(participants.get(0)==user){
            return participants.get(1);
        }else if(participants.get(1)==user){
            return participants.get(0);
        }
        return null;
    }

}
